-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mer. 04 mai 2022 à 01:03
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `cube3`
--

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

DROP TABLE IF EXISTS `produit`;
CREATE TABLE IF NOT EXISTS `produit` (
  `id_produit` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `urlPhoto` varchar(50) NOT NULL,
  `prix` float DEFAULT NULL,
  PRIMARY KEY (`id_produit`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`id_produit`, `nom`, `description`, `urlPhoto`, `prix`) VALUES
(1, 'Paint War', 'Paint War est un jeu de tir ï¿½ la premiï¿½re personne. Deux joueurs s\'affrontent, chacun ayant choisi un personnage et une arme. Le style graphique ï¿½purï¿½ de ce deuxiï¿½me jeu dï¿½veloppï¿½ par Zepplinium va de paire avec son gameplay : ï¿½ la fois simple ï¿½ prendre en main et complexe par sa diversitï¿½.', 'product1.png', 42.69),
(2, 'Primal Tales Adventures', 'Primal Tale: Adventure est le premier jeu développé par Zepplinium. Lâché tel une bombe dans l\'univers du jeu vidéo, il a révolutionné ce dernier et a inspiré de nombreux studios. Vous incarnez Arakiel, un adolescent solitaire et orphelin lâché dans un monde pas si innocent qu\'il n\'y paraît...', 'product2.png', 69.42);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
